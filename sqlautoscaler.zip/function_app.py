from __future__ import annotations

import logging
from datetime import datetime, timezone

import azure.functions as func
from azure.identity import DefaultAzureCredential

from src.azure_sql_client import AzureSqlDatabaseClient
from src.config import Config, ConfigError
from src.decision_engine import compute_decision
from src.locking import try_acquire_singleflight_lock
from src.maxdop import build_maxdop_statement, compute_maxdop
from src.schedule import determine_floor_vcores
from src.sql_metrics import execute_statement, fetch_metric_signal
from src.state_store import StateEntity, TableStateStore

app = func.FunctionApp()


@app.timer_trigger(
    arg_name="timer",
    schedule="0 */1 * * * *",
    run_on_startup=False,
    use_monitor=False,
)
def sql_vcore_autoscaler(timer: func.TimerRequest) -> None:
    del timer

    now_utc = datetime.now(timezone.utc)

    try:
        config = Config.from_env()
    except ConfigError:
        logging.exception("Configuration error. Autoscaler cycle aborted.")
        return

    lock_blob_name = f"{config.sql_server_name.lower()}-{config.sql_database_name.lower()}.lock"
    with try_acquire_singleflight_lock(
        connection_string=config.storage_connection_string,
        container_name=config.lock_container_name,
        blob_name=lock_blob_name,
        lease_seconds=config.lock_lease_seconds,
    ) as lock_acquired:
        if not lock_acquired:
            logging.info("Another autoscaler instance holds the lock. Skipping this cycle.")
            return

        credential = DefaultAzureCredential()
        state_store = TableStateStore(
            connection_string=config.storage_connection_string,
            table_name=config.state_table_name,
        )
        state = state_store.get_state(
            server_name=config.sql_server_name,
            database_name=config.sql_database_name,
        )

        sql_client = AzureSqlDatabaseClient(
            subscription_id=config.subscription_id,
            credential=credential,
            resource_group=config.resource_group,
            server_name=config.sql_server_name,
            database_name=config.sql_database_name,
        )

        try:
            current_compute = sql_client.get_database_compute()
        except Exception:
            state.last_error = "compute_read_failed"
            state_store.upsert_state(state)
            logging.exception("Failed to read current database compute metadata.")
            return

        if _handle_pending_if_present(
            config=config,
            credential=credential,
            state=state,
            state_store=state_store,
            current_vcores=current_compute.vcores,
            now_utc=now_utc,
        ):
            return

        if not _ensure_maxdop_synced(
            config=config,
            credential=credential,
            state=state,
            state_store=state_store,
            current_vcores=current_compute.vcores,
        ):
            return

        now_local = now_utc.astimezone(config.timezone)
        floor_vcores = determine_floor_vcores(
            local_now=now_local,
            business_days=config.business_days,
            business_start=config.business_start,
            business_end=config.business_end,
            min_vcores_business=config.min_vcores_business,
            min_vcores_offhours=config.min_vcores_offhours,
        )

        try:
            metrics = fetch_metric_signal(config=config, credential=credential)
        except Exception:
            state.last_error = "metrics_query_failed"
            state_store.upsert_state(state)
            logging.exception("Failed querying sys.dm_db_resource_stats.")
            return

        decision = compute_decision(
            current_vcores=current_compute.vcores,
            floor_vcores=floor_vcores,
            max_vcores=config.max_vcores,
            step_vcores=config.step_vcores,
            metrics=metrics,
            last_scale_completed_utc=state.last_scale_completed_utc,
            now_utc=now_utc,
            up_window_samples=config.up_window_samples,
            down_window_samples=config.down_window_samples,
            up_cooldown_min=config.up_cooldown_min,
            down_cooldown_min=config.down_cooldown_min,
        )

        logging.info(
            "Decision=%s target=%s reason=%s current=%s floor=%s samples=%s up_hits=%s down_hits=%s",
            decision.action,
            decision.target_vcores,
            decision.reason,
            current_compute.vcores,
            floor_vcores,
            metrics.sample_count,
            metrics.up_hits,
            metrics.down_hits,
        )

        if decision.action == "none" or decision.target_vcores == current_compute.vcores:
            state.last_error = None
            state_store.upsert_state(state)
            return

        if config.dry_run:
            logging.warning(
                "DRY_RUN enabled. Would scale %s from %s to %s vCores.",
                decision.action,
                current_compute.vcores,
                decision.target_vcores,
            )
            state.last_error = None
            state_store.upsert_state(state)
            return

        try:
            sql_client.request_scale(current=current_compute, target_vcores=decision.target_vcores)
        except Exception:
            state.last_error = "scale_request_failed"
            state_store.upsert_state(state)
            logging.exception("Scale request failed for target vCores=%s", decision.target_vcores)
            return

        state.last_action = decision.action
        state.set_pending(
            target_vcores=decision.target_vcores,
            now_utc=now_utc,
            timeout_min=config.scale_pending_timeout_min,
        )
        state.last_error = None
        state_store.upsert_state(state)

        logging.warning(
            "Scale requested action=%s from=%s to=%s",
            decision.action,
            current_compute.vcores,
            decision.target_vcores,
        )


def _handle_pending_if_present(
    *,
    config: Config,
    credential: DefaultAzureCredential,
    state: StateEntity,
    state_store: TableStateStore,
    current_vcores: int,
    now_utc: datetime,
) -> bool:
    if state.pending_target_vcores is None:
        return False

    if current_vcores == state.pending_target_vcores:
        state.last_scale_completed_utc = now_utc
        state.clear_pending()
        if _sync_maxdop(
            config=config,
            credential=credential,
            state=state,
            current_vcores=current_vcores,
        ):
            state.last_error = None
        state_store.upsert_state(state)
        logging.info("Pending scale completed at %s vCores.", current_vcores)
        return True

    if state.pending_deadline_utc and now_utc < state.pending_deadline_utc:
        logging.info(
            "Scale still pending target=%s current=%s deadline=%s",
            state.pending_target_vcores,
            current_vcores,
            state.pending_deadline_utc,
        )
        return True

    state.clear_pending()
    state.last_error = "scale_pending_timeout"
    state_store.upsert_state(state)
    logging.error("ALERT: scale operation exceeded pending timeout; cleared pending state.")
    return False


def _ensure_maxdop_synced(
    *,
    config: Config,
    credential: DefaultAzureCredential,
    state: StateEntity,
    state_store: TableStateStore,
    current_vcores: int,
) -> bool:
    desired_maxdop = compute_maxdop(current_vcores)
    if state.last_maxdop == desired_maxdop:
        return True

    if config.dry_run:
        logging.info(
            "DRY_RUN enabled. Would set MAXDOP to %s for current_vcores=%s.",
            desired_maxdop,
            current_vcores,
        )
        return True

    if _sync_maxdop(
        config=config,
        credential=credential,
        state=state,
        current_vcores=current_vcores,
    ):
        state.last_error = None
        state_store.upsert_state(state)
        return True

    state.last_error = "maxdop_sync_failed"
    state_store.upsert_state(state)
    logging.error("ALERT: failed to sync MAXDOP; will retry next cycle.")
    return False


def _sync_maxdop(
    *,
    config: Config,
    credential: DefaultAzureCredential,
    state: StateEntity,
    current_vcores: int,
) -> bool:
    maxdop = compute_maxdop(current_vcores)
    statement = build_maxdop_statement(maxdop)

    try:
        execute_statement(config=config, credential=credential, statement=statement)
    except Exception:
        logging.exception("MAXDOP update failed for value=%s", maxdop)
        return False

    state.last_maxdop = maxdop
    logging.info("MAXDOP set to %s for vCores=%s", maxdop, current_vcores)
    return True
