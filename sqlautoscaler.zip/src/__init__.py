"""Azure SQL autoscaler package."""
