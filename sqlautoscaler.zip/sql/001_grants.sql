/*
Run in the target Azure SQL Database.
Replace <FUNCTION_MANAGED_IDENTITY_NAME> with the exact managed identity display name.
*/

DECLARE @principal SYSNAME = N'<FUNCTION_MANAGED_IDENTITY_NAME>';

IF NOT EXISTS (
    SELECT 1
    FROM sys.database_principals
    WHERE name = @principal
)
BEGIN
    DECLARE @create_user_sql NVARCHAR(4000) = N'CREATE USER [' + REPLACE(@principal, N']', N']]') + N'] FROM EXTERNAL PROVIDER;';
    EXEC sp_executesql @create_user_sql;
END;

DECLARE @grant_view_state_sql NVARCHAR(4000) = N'GRANT VIEW DATABASE STATE TO [' + REPLACE(@principal, N']', N']]') + N'];';
DECLARE @grant_scoped_cfg_sql NVARCHAR(4000) = N'GRANT ALTER ANY DATABASE SCOPED CONFIGURATION TO [' + REPLACE(@principal, N']', N']]') + N'];';

EXEC sp_executesql @grant_view_state_sql;
EXEC sp_executesql @grant_scoped_cfg_sql;
